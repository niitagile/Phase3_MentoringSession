package services;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import beans.UserDetails;


@WebServlet("/HibernateTestServlet")
public class HibernateTestServlet extends HttpServlet {
	
	
	private static final long serialVersionUID = 1L;
	
	void register(UserDetails user){
		/*StandardServiceRegistry ssr=new StandardServiceRegistryBuilder().configure("com/virtusa/confi/hibernate.cfg.xml").build();
    	Metadata meta=new MetadataSources(ssr).getMetadataBuilder().build();
    	SessionFactory sessionFactory=meta.getSessionFactoryBuilder().build();*/
		//SessionFactory sessionFactory=new Configuration().configure("/HibernateExample/src/hibernate.cfg.xml").buildSessionFactory();
		SessionFactory sessionFactory=new Configuration().configure(new File("E:/workspace5/HibernateAnnoExample/src/hibernate.cfg.xml")).buildSessionFactory();
		Session session=sessionFactory.openSession();
		session.beginTransaction();
		session.save(user);
		
		session.getTransaction().commit();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UserDetails user=new UserDetails();
		int uid=Integer.parseInt(request.getParameter("txtUid"));
		String uname=request.getParameter("txtName");
		user.setId(uid);
		user.setUsername(uname);
		register(user);
	}

}
